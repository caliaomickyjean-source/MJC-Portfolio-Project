# MJC Portfolio

Personal portfolio website for Micky Jean Caliao.

## Files
- index.html
- Images (add your JPG files to the same folder)

## Publishing on GitHub Pages
1. Create a public GitHub repository.
2. Upload all files.
3. Go to Settings > Pages.
4. Deploy from the main branch.
